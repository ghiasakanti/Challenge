package Challange82;

public class Demo {

	public static void main(String[] args) {
		
		Prime prime = new Prime();
		Thread thread1 = new Thread(prime);
		thread1.start();
		
		Fibonacci fibonacci = new Fibonacci();
		Thread thread2 = new Thread(fibonacci);
		thread2.start();
		
	}
}
