package Challange82;

public class Fibonacci implements Runnable{

	@Override
	public void run() {
		try {
			
			Thread.sleep(120000);
			
			int x = 20, AngkaA = 0, AngkaB = 1;
			System.out.println(x + "bilangan Fibonacci: ");

			for (int i = 1; i <= x; ++i) {
				System.out.print(AngkaA + " , ");
				int sum = AngkaA + AngkaB;
				AngkaA = AngkaB;
				AngkaA = sum;
			}
		} catch (InterruptedException e) {
	
		}
		
	}

}
