package Challange82;

public class Prime implements Runnable{

	@Override
	public void run() {
		
		System.out.println("Harap Tunggu 1 menit untuk 10 bilangan prima pertama");
		
		try {
			
			Thread.sleep(60000);
			
			int x = 30;
	        System.out.println("10 Bilangan Prima Pertama: ");
	        
	        for(int i = 2; i < x; i++) {
	        	
	            boolean isPrima = true;
	            
	            for (int j = 2; j < i; j++) {
	            	
	                if(i%j==0){
	                	
	                    isPrima = false;
	                    break;
	                    
	                }
	            }
	            if(isPrima==true){
	            	
	                System.out.print(i + " , ");
	            }
	        }
	        
	        System.out.println(" ");
	        System.out.println("Harap tunggu 1 menit untuk 20 bilangan Fibonacci pertama");
	        
		} catch (InterruptedException e) {

		}
		
	}
	
	}


