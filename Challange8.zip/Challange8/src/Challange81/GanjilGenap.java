package Challange81;

public class GanjilGenap implements Runnable{

	int Angka;
	
	public GanjilGenap(int Angka) {
		System.out.println("Harap menunggu selama 30 detik");
		this.Angka = Angka;
	}

	@Override
	public void run() {
		try {
			
			Thread.sleep(30000);
			
			if(Angka %2 == 1){
				
				System.out.println("Angka Ganjil");
			}
			
			else{
				
				System.out.println("Angka Genap");
				
			}
		} catch (InterruptedException e) {
	}
		
}

}
