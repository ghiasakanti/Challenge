package Challange81;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int Angka;
		
		System.out.println("Input Angka: ");
		Angka = scan.nextInt();scan.nextLine();
		GanjilGenap ganjilGenap = new GanjilGenap(Angka);
		Thread thread1 = new Thread(ganjilGenap);
		thread1.start();
		
		Fibonacci fibonacci = new Fibonacci(Angka);
		Thread thread2 = new Thread(fibonacci);
		thread2.start();
	}

}
