package Challange81;

public class Fibonacci implements Runnable{
	
	int Angka;

	public Fibonacci(int Angka) {
		this.Angka = Angka;
	}

	@Override
	public void run() {
		
		int x = 20, AngkaA = 0, AngkaB = 1;
		System.out.println(x + "Angka Fibonacci:");

		for (int i = 1; i <= x; ++i) {
			
			System.out.print(AngkaA + " ");
			
			int sum = AngkaA + AngkaB;
			AngkaA = AngkaB;
			AngkaB  = sum;

			if (sum != AngkaA + AngkaB && AngkaA != AngkaB && AngkaB != sum) {
				
				System.out.println("Bukan Fibonacci");
				
			} else {
				
				System.out.println("Bilangan Fibonacci");
			}
		}
		
		System.out.println("Jika angka yang dimasukan tidak keluar, maka angka tersebut bukan bilangan Fibonacci");
		
}

}
