package Challange5;

import java.util.Scanner;

public class Main {
	
	Scanner scan = new Scanner(System.in);

	public Main() {
		int choice;
		
		do {
			do {
				System.out.println("1. Bangun Datar: ");
				System.out.println("2. Bangun Ruang: ");
				System.out.println("3. Exit");
				System.out.println("Choice: ");
				choice = scan.nextInt();scan.nextLine();

			} while (choice <1 || choice >3);
			
			switch (choice) {
			case 1:
				bangunDatar();
				break;

			case 2:
				bangunRuang();	
				break;
			}
			
		} while (choice != 3);
	}
		
		public void bangunDatar(){
			int choice;
			
			System.out.println("1. Persegi ");
			System.out.println("2. Persegi Panjang ");
			System.out.println("3. Lingkaran");
			System.out.println("4. Segitiga");
			System.out.println("5. Exit");
			System.out.println("Choice");
			choice = scan.nextInt();scan.nextLine();

			switch (choice) {
			case 1:
				
				int Panjang;
				
				System.out.println("Masukkan Berapa Panjang: ");
				Panjang = scan.nextInt();scan.nextLine();
				
				Persegi persegi = new Persegi(Panjang);
				
				persegi.Luas();
				persegi.Keliling();
				
				break;

			case 2:
				
				int Panjang1, Lebar;
				
				System.out.println("Masukkan Berapa Panjang: ");
				Panjang1 = scan.nextInt();scan.nextLine();
				
				System.out.println("Masukkan Berapa Lebar");
				Lebar = scan.nextInt(); scan.nextLine();
				
				Persegipanjang persegipanjang = new Persegipanjang(Panjang1 , Lebar);
				
				break;
			
			case 3:
				
				int r;
				
				System.out.println("Masukkan Berapa Jari - Jari: ");
				r = scan.nextInt();scan.nextLine();
				
				Lingkaran lingkaran = new Lingkaran(r);
				
				lingkaran.Luas();
				lingkaran.Keliling();
				
				break;
			
			case 4:
				int Alas, Tinggi, Sisia , Sisib, Sisic;
				
				System.out.println("Masukan Berapa Alas: ");
				Alas = scan.nextInt();scan.nextLine();
				System.out.println("Masukan Berapa Tinggi: ");
				Tinggi = scan.nextInt();scan.nextLine();
				System.out.println("Masukan Berapa sisi A: ");
				Sisia = scan.nextInt();scan.nextLine();
				System.out.println("Masukan Berapa sisi B: ");
				Sisib = scan.nextInt();scan.nextLine();
				System.out.println("Masukan sisi C: ");
				Sisic = scan.nextInt();scan.nextLine();
				Segitiga segitiga = new Segitiga(Alas, Tinggi, Sisia, Sisib, Sisic);
				
				segitiga.Luas();
				segitiga.Keliling();
				
				break;
				
			}
		}
				
		public void bangunRuang(){
			int choice;
			
			System.out.println("1. Kubus: ");
			System.out.println("2. Balok: ");
			System.out.println("3. Bola");
			System.out.println("4. Exit");
			System.out.println("Choice");
			choice = scan.nextInt();scan.nextLine();	
			
			switch (choice) {
			case 1:
				
				int Sisi;
				
				System.out.println("Masukan Berapa sisi: ");
				Sisi = scan.nextInt();scan.nextLine();
				Kubus kubus = new Kubus(Sisi);
		
				kubus.Luas();
				kubus.Keliling();
				kubus.Volume();
				
				break;

			case 2:
				
				int Panjang;
				int Lebar;
				int Tinggi;
				
				System.out.println("Masukan Berapa Panjang: ");
				Panjang = scan.nextInt();scan.nextLine();
				System.out.println("Masukan Berapa Lebar: ");
				Lebar = scan.nextInt();scan.nextLine();
				System.out.println("Masukan Berapa Tinggi: ");
				Tinggi = scan.nextInt();scan.nextLine();
				
				Balok balok = new Balok(Panjang, Lebar, Tinggi);
		
				balok.Luas();
				balok.Keliling();
				balok.Volume();
				
				break;
			
			case 3:
				
				int r;
				
				System.out.println("Masukan Berapa Jari - Jari: ");
				r = scan.nextInt();scan.nextLine();
				
				Bola bola = new Bola(r);
				
				bola.Luas();
				bola.Keliling();
				bola.Volume();
				
				break;
			}
			}	
					
	
		
		

	public static void main(String[] args) {
		new Main();

	}

}
