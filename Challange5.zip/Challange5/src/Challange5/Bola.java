package Challange5;

public class Bola extends BangunRuang{
	private int r;
	
	@Override
	double Luas() {
		double Luas = (float)(4 * Math.PI * r * r);
		System.out.println("Luas Bola: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = (float) (1.3 * Math.PI * r * r);
		System.out.println("Keliling Bola: " + Keliling);
		return super.Keliling();
	}

	@Override
	double Volume() {
		double Volume = (float) (1.3 * Math.PI * r * r * r);
		System.out.println("Volume Bola: "+ Volume);
		return super.Volume();
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public Bola(int r) {
		super();
		this.r = r;
	}

}
