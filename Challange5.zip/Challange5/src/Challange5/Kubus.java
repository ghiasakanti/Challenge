package Challange5;

public class Kubus extends BangunRuang{
	
	private int Sisi;

	@Override
	double Luas() {
		double Luas = 6 * Sisi * Sisi;
		System.out.println("Luas kubus: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = 12 * Sisi;
		System.out.println("Keliling kubus: " + Keliling);
		return super.Keliling();
	}

	@Override
	double Volume() {
		double Volume = Sisi * Sisi * Sisi;
		System.out.println("Volume kubus: " + Volume);
		return super.Volume();
	}

	public int getSisi() {
		return Sisi;
	}

	public void setSisi(int sisi) {
		Sisi = sisi;
	}

	public Kubus(int Sisi) {
		super();
		this.Sisi = Sisi;
	}


}
